package Sockets.juego;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Juego extends JFrame implements ActionListener {

    private Color colorActual = Color.RED;
    private JButton[][] botones;

    public Juego() {
        super("Matriz de Botones");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setSize(650, 700);

        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(null);

        add(panelBotones);

        botones = new JButton[10][10];
        int tamanio_botones = 50;
        int xmargen = 1;
        int ymargen = 1;

        for (int fila = 0; fila < 10; fila++) {
            for (int colum = 0; colum < 10; colum++) {
                JButton boton = new JButton();

                int x = xmargen + colum * (tamanio_botones + xmargen);
                int y = ymargen + fila * (tamanio_botones + ymargen);

                boton.setBounds(x, y, tamanio_botones, tamanio_botones);

                String nombreImagen = "src/Sockets/juego/Imagen/mar.jpg";
                ImageIcon icono = new ImageIcon(nombreImagen);
                boton.setIcon(icono);
                boton.setMargin(new Insets(0, 0, 0, 0));
                boton.addActionListener(this);
                panelBotones.add(boton);
                botones[fila][colum] = boton;
            }
        }

        JButton botonRestablecer = new JButton("Restablecer");
        botonRestablecer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                restablecerBotones();
            }
        });
        botonRestablecer.setBounds(xmargen, ymargen + 10 * (tamanio_botones + ymargen), tamanio_botones * 5, tamanio_botones);
        panelBotones.add(botonRestablecer);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        for (int fila = 0; fila < 10; fila++) {
            for (int colum = 0; colum < 10; colum++) {
                JButton boton = botones[fila][colum];
                if (e.getSource() == boton) {
                    boton.setBackground(colorActual);
                    boton.setIcon(null);
                    boton.setEnabled(false);

                    if (colorActual.equals(Color.RED)) {
                        colorActual = Color.GREEN;
                    } else {
                        colorActual = Color.RED;
                    }
                    return; // Salir del método actionPerformed después de encontrar el botón correspondiente
                }
            }
        }
    }

    public void restablecerBotones() {
        colorActual = Color.RED;
        for (int fila = 0; fila < 10; fila++) {
            for (int colum = 0; colum < 10; colum++) {
                JButton boton = botones[fila][colum];
                boton.setBackground(null);
                boton.setIcon(new ImageIcon("src/Sockets/juego/Imagen/mar.jpg"));
                boton.setEnabled(true);
            }
        }
    }

    public static void main(String[] args) {
        new Juego();
    }
}
