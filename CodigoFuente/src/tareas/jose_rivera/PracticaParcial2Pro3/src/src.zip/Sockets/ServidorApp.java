package Sockets;

public class ServidorApp {
    public static void main(String[] args) {
        ServidorObject servidor = new ServidorObject();
    }
}